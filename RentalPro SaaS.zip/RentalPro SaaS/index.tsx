const { execSync } = require('child_process');

// Function to run shell commands
function runCommand(command) {
  try {
    const output = execSync(command, { encoding: 'utf-8' });
    console.log(output);
  } catch (error) {
    console.error(`Error executing command: ${command}`);
    console.error(error.message);
  }
}

// Initialize Git repository
runCommand('git init');

// Add all files to staging
runCommand('git add .');

// Create initial commit
runCommand('git commit -m "Initial commit: RentalPro SaaS application"');

console.log('Git repository created and initial commit made successfully!');

// Instructions for creating a remote repository
console.log('\nNext steps:');
console.log('1. Create a new repository on GitHub, GitLab, or Bitbucket');
console.log('2. Copy the remote repository URL');
console.log('3. Run the following command to add the remote:');
console.log('   git remote add origin <your-repository-url>');
console.log('4. Push your code to the remote repository:');
console.log('   git push -u origin main');